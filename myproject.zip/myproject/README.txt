Buoc 1 Kiem tra va tao database

Mo phpMyAdmin theo link http://localhost/phpmyadmin
Copy toan bo Script SQL v� paste v�o tab SQL
Click Go doi chay script tao database
Bu?c 2: Test voi file debug

file debug.php voi noi dung d� cung cap
Truy cap http://localhost/debug.php
Kiem tra c�c th�ng tin debug de x�c dinh lai
Bu?c 3: Su dung phi�n ban don gian

simple_auth.php voi code 
Truy cap http://localhost/simple_auth.php
Test dang k�/dang nhap voi form don gion hon

T�i khoan test c� san:

Admin: admin / admin123
User mau: user1 / 123456